public class DFATable {
    public static void main(String[] args) {
        // Table header
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "State", "Action", "Rule", "Input 2", "Input 3", "Input 4", "E");

        // Table rows
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "0", "Shift", "", "3", "6", "2", "1");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "1", "Reduce", "E->E", "", "", "", "");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "2", "Reduce", "E->4", "", "", "", "");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "3", "Shift", "", "3", "6", "2", "4");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "4", "Shift", "", "5", "", "", "");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "5", "Reduce", "E->2E2", "", "", "", "");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "6", "Shift", "", "", "3", "", "2");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "7", "Shift", "", "8", "", "", "");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-10s%-10s\n", "8", "Reduce", "E->3E3", "", "", "", "");
    }
}
