public class Dfa {
    static int dfa = 0;

    // State transition functions
    static void stat_0(char a) {
        if (dfa == 0 && a == 'E') {
            dfa = 1;
        } 
        else if(a=='2'){
            dfa=3;
        }
        else if(a=='3'){
            dfa=6;
        }
        else if(a=='4'){
            dfa=2;
        }
        else {
            dfa = -1;
        }
    }
    static void stat_1(char a) {
        
            dfa = 1;
        
    }
        static void stat_2(char a) {
            
                dfa = 2;
           
        }
    
    static void stat_3(char a) {
        if (a == '3') {
            dfa = 6;
        } else if (a == 'E' && dfa == 3) {
            dfa = 4;
        }
        else if(a=='4'){
         dfa=2;
        }
        else if(dfa==3 && a=='E'){
            dfa=3;
        }
         else {
            dfa = -1;
        }
    }

    
    static void stat_4(char a) {
        if(a=='2'){
            dfa=5;
        }
        else{
            dfa=-1;
        }
    }

    static void stat_5(char a) {
       
            dfa = 5;
      
    }

    static void stat_6(char a) {
        if (a == '2') {
            dfa = 3;
        } else if (a=='4') {
            dfa = 2;
        } 
        else if(a=='E'&& dfa==6){
            dfa = 7;
        }
        else {
            dfa = -1;
        }
    }

    static void stat_7(char a) {
        if (a == '3') {
            dfa = 8;
        } else {
            dfa = -1;
        }
    }
    static void stat_8(char a) {
       dfa=8;
    }

    static String isAccepted(char str[]) {
        // store length of string
        int i, len = str.length;

        for (i = 0; i < len; i++) {
            if (dfa == 0) {
                stat_0(str[i]);
            } else if (dfa == 1) {
                stat_1(str[i]);
            } else if (dfa == 2) {
                stat_2(str[i]);
            } else if (dfa == 3) {
                stat_3(str[i]);
            } else if (dfa == 4) {
                stat_4(str[i]);
            } else if (dfa == 5) {
                stat_5(str[i]);
            } else if (dfa == 6) {
                stat_6(str[i]);
            } else if (dfa == 7) {
                stat_7(str[i]);
            } 
            else if (dfa == 8) {
                stat_8(str[i]);
            }
            else {
                return "invalid";
            }
        }

        if (dfa == 1) {
            return "shift";
        } else if (dfa == 2 || dfa == 8 || dfa == 5||dfa==1) {
            return "reduce";
        } else {
            return "invalid";
        }
    }

    public static void main(String[] args) {
        char str[] = "2E2".toCharArray();
        String result = isAccepted(str);
        if (result.equals("shift")) {
            System.out.printf("ACCEPTED (Shift)\n");
        } else if (result.equals("reduce")) {
            System.out.printf("ACCEPTED (Reduce)\n");
        } else {
            System.out.printf("NOT ACCEPTED\n");
        }
    }
}
