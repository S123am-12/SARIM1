import java.util.Arrays;

public class BottomUpParser {
    // Global Variables
    static int z = 0, i = 0, j = 0, c = 0;

    // Modify array size to increase length of string to be parsed
    static char[] a = new char[16];
    static char[] ac = new char[20];
    static char[] stk = new char[15];
    static char[] act = new char[10];

    // This Function will check whether the stack contains a production rule which is to be Reduced.
    // Rules can be E->2E2, E->3E3, E->4
    static void check() {
        // Copying string to be printed as action
        String acStr = "REDUCE TO E -> ";

        // c=length of input string
        for (z = 0; z < c; z++) {
            // checking for producing rule E->4
            if (stk[z] == '4') {
                System.out.print(acStr + "4");
                stk[z] = 'E';
                stk[z + 1] = '\0';

                // printing action
                System.out.print("\n$");
                System.out.print(new String(stk).trim());
                System.out.print("\t");
                System.out.print(new String(a).trim());
                System.out.print("$\t");
            }
        }

        for (z = 0; z < c - 2; z++) {
            // checking for another production
            if (stk[z] == '2' && stk[z + 1] == 'E' && stk[z + 2] == '2') {
                System.out.print(acStr + "2E2");
                stk[z] = 'E';
                stk[z + 1] = '\0';
                stk[z + 2] = '\0';
                System.out.print("\n$");
                System.out.print(new String(stk).trim());
                System.out.print("\t");
                System.out.print(new String(a).trim());
                System.out.print("$\t");
                i = i - 2;
            }
        }

        for (z = 0; z < c - 2; z++) {
            // checking for E->3E3
            if (stk[z] == '3' && stk[z + 1] == 'E' && stk[z + 2] == '3') {
                System.out.print(acStr + "3E3");
                stk[z] = 'E';
                stk[z + 1] = '\0';
                stk[z + 2] = '\0';
                System.out.print("\n$");
                System.out.print(new String(stk).trim());
                System.out.print("\t");
                System.out.print(new String(a).trim());
                System.out.print("$\t");
                i = i - 2;
            }
        }
        return; // return to main
    }

    // Driver Function
    public static void main(String[] args) {
        System.out.println("GRAMMAR is -\nE->2E2 \nE->3E3 \nE->4");

        // a is input string
        a = "32423".toCharArray();

        // length of input string
        c = a.length;

        // "SHIFT" is copied to act to be printed
        act = "SHIFT".toCharArray();

        // This will print Labels (column name)
        System.out.println("\nstack \t input \t action");

        // This will print the initial values of stack and input
        System.out.print("\n$\t");
        System.out.print(new String(a).trim());
        System.out.print("$\t");

        // This will run up to length of input string
        for (i = 0; j < c; i++, j++) {
            // Printing action
            System.out.print(new String(act).trim());

            // Pushing into stack
            stk[i] = a[j];
            stk[i + 1] = '\0';

            // Moving the pointer
            a[j] = ' ';

            // Printing action
            System.out.print("\n$");
            System.out.print(new String(stk).trim());
            System.out.print("\t");
            System.out.print(new String(a).trim());
            System.out.print("$\t");

            // Call check function ..which will check the stack whether it contains any production or not
            check();
        }

        // Rechecking last time if contain any valid production then it will replace otherwise invalid
        check();

        // if top of the stack is E(starting symbol) then it will accept the input
        if (stk[0] == 'E' && stk[1] == '\0') {
            System.out.println("Accept");
        } else { // else reject
            System.out.println("Reject");
        }
    }
}
